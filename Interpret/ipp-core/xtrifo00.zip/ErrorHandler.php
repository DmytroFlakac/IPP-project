<?php

namespace IPP\Student;
use IPP\Core\Exception;
use IPP\Core\Exception\IPPException;


class ErrorHandler extends IPPException
{
    public static function ErrorMessage(int $code, string $message, int $order): void
    {
        if($order === -1)
            fwrite(STDERR, $message . PHP_EOL);
        else
            fwrite(STDERR, $message .  ": Instruction-> $order" . PHP_EOL);
        exit($code);
    }
}